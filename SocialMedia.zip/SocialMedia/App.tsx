/*import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Pressable,
  FlatList,
} from 'react-native';
import Title from './components/Title/Title';
import UserStory from './components/UserStory/UserStory';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome';
import {faEnvelope} from '@fortawesome/free-regular-svg-icons';
import style from './assets/styles/main';
import UserPosts from './components/UserPosts/UserPost';
const App = () => {
  const data = [
    {
      firstName: 'ali',
      id: 1,
    },
    {
      firstName: 'Angel',
      id: 2,
    },
    {
      firstName: 'white',
      id: 3,
    },
    {
      firstName: 'sara',
      id: 4,
    },
    {
      firstName: 'reza',
      id: 5,
    },
    {
      firstName: 'mahdi',
      id: 6,
    },
    {
      firstName: 'bita',
      id: 7,
    },
    {
      firstName: 'mani',
      id: 8,
    },
    {
      firstName: 'shabnam',
      id: 9,
    },
  ];
  const posts = [
    {
      firstName: 'sepanta',
      lastName: 'alizadeh',
      location: 'iran, tehran',
      likes: 2340,
      comments: 356,
      bookmarks: 55,
      id: 1,
    },
    {
      firstName: 'selena',
      lastName: 'gomez',
      location: 'usa, newyork',
      likes: 6340,
      comments: 956,
      bookmarks: 455,
      id: 2,
    },
    {
      firstName: 'ela',
      lastName: 'ka..',
      location: 'iran, tehran',
      likes: 40,
      comments: 56,
      bookmarks: 5,
      id: 3,
    },
    {
      firstName: 'reza',
      lastName: 'asadi',
      location: 'iran, tehran',
      likes: 20,
      comments: 6,
      bookmarks: 45,
      id: 4,
    },
    {
      firstName: 'mahshid',
      lastName: 'nazarai',
      location: 'iran, tehran',
      likes: 980,
      comments: 876,
      bookmarks: 15,
      id: 5,
    },
  ];
  const pageSize = 4;
  const pageSizePosts = 2;
  const [pageNumber, setPageNumber] = useState(1);
  const [postPageNumber, setPostPageNumber] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  const [renderedData, setRenderedData] = useState(data.slice(0, pageSize));
  const [renderedDataPosts, setRenderedDataPosts] = useState(
    posts.slice(0, pageSize),
  );

  const pagination = (data, pageNumber, pageSize, posts: boolean = false) => {
    let startIndex = (pageNumber - 1) * pageSize;
    console.log(startIndex, renderedData.length);
    if (startIndex >= data.length) {
      return [];
    }
    if (!posts) {
      setPageNumber(pageNumber);
    } else {
      setPostPageNumber(pageNumber);
    }
    setPageNumber(pageNumber);
    return data.slice(startIndex, startIndex + pageSize);
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={style.header}>
          <Title title={'Lets Explore'} />
          <Pressable style={style.messageIcon}>
            <FontAwesomeIcon icon={faEnvelope} color="#CACDDE" size={20} />
            <View style={style.messageNumberContainer}>
              <Text style={style.messageNumber}>2</Text>
            </View>
          </Pressable>
        </View>
        <View style={style.userStoryContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoading(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading) {
                setIsLoading(true);
                setRenderedData(prev => [
                  ...prev,
                  ...pagination(data, pageNumber + 1, pageSize),
                ]);
                setIsLoading(false);
              }
            }}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            data={renderedData}
            renderItem={({item}) => <UserStory firstName={item.firstName} />}
            keyExtractor={item => item.id.toString()}
          />
        </View>
        <View style={style.userPostContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoadingPosts(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading) {
                setIsLoadingPosts(true);
                setRenderedDataPosts(prev => [
                  ...prev,
                  ...pagination(posts, pageNumber + 1, pageSize,true),
                ]);
                setIsLoadingPosts(false);
              }
            }}
            showsVerticalScrollIndicator={false}
            data={renderedDataPosts}
            renderItem={({item}) => (
              <UserPosts
                firstName={item.firstName}
                lastName={item.lastName}
                comments={item.comments}
                likes={item.likes}
                bookmarks={item.bookmarks}
                location={item.location}
              />
            )}
            keyExtractor={item => item.id.toString()}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default App;
*/

// App.js
/*import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Pressable,
  FlatList,
} from 'react-native';
import Title from './components/Title/Title';
import UserStory from './components/UserStory/UserStory';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome';
import {faEnvelope} from '@fortawesome/free-regular-svg-icons';
import style from './assets/styles/main';
import UserPosts from './components/UserPosts/UserPost';

const App = () => {
  const data = [
    { firstName: 'ali', id: 1, imageSource: require('./assets/images/1.jpg') },
    { firstName: 'Angel', id: 2, imageSource: require('./assets/images/1.jpg') },
    { firstName: 'white', id: 3, imageSource: require('./assets/images/2.jpg') },
    { firstName: 'sara', id: 4, imageSource: require('./assets/images/2.jpg') },
    { firstName: 'reza', id: 5, imageSource: require('./assets/images/3.jpg') },
    { firstName: 'mahdi', id: 6, imageSource: require('./assets/images/3.jpg') },
    { firstName: 'bita', id: 7, imageSource: require('./assets/images/4.jpg') },
    { firstName: 'mani', id: 8, imageSource: require('./assets/images/4.jpg') },
    { firstName: 'shabnam', id: 9, imageSource: require('./assets/images/4.jpg') },
  ];

  const posts = [
    {
      firstName: 'sepanta',
      lastName: 'alizadeh',
      location: 'iran, tehran',
      likes: 2340,
      comments: 356,
      bookmarks: 55,
      id: 1,
      profileImage: require('./assets/images/1.jpg'),
      postImage: require('./assets/images/1.jpg'),
    },
    {
      firstName: 'selena',
      lastName: 'gomez',
      location: 'usa, newyork',
      likes: 6340,
      comments: 956,
      bookmarks: 455,
      id: 2,
      profileImage: require('./assets/images/3.jpg'),
      postImage: require('./assets/images/3.jpg'),
    },
    {
      firstName: 'ela',
      lastName: 'ka..',
      location: 'iran, tehran',
      likes: 40,
      comments: 56,
      bookmarks: 5,
      id: 3,
      profileImage: require('./assets/images/4.jpg'),
      postImage: require('./assets/images/4.jpg'),
    },
    {
      firstName: 'reza',
      lastName: 'asadi',
      location: 'iran, tehran',
      likes: 20,
      comments: 6,
      bookmarks: 45,
      id: 4,
      profileImage: require('./assets/images/5.jpg'),
      postImage: require('./assets/images/5.jpg'),
    },
    {
      firstName: 'mahshid',
      lastName: 'nazarai',
      location: 'iran, tehran',
      likes: 980,
      comments: 876,
      bookmarks: 15,
      id: 5,
      profileImage: require('./assets/images/6.jpg'),
      postImage: require('./assets/images/6.jpg'),
    },
  ];

  const pageSize = 4;
  const pageSizePosts = 2;
  const [pageNumber, setPageNumber] = useState(1);
  const [postPageNumber, setPostPageNumber] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  const [renderedData, setRenderedData] = useState(data.slice(0, pageSize));
  const [renderedDataPosts, setRenderedDataPosts] = useState(
    posts.slice(0, pageSizePosts),
  );

  const pagination = (data, pageNumber, pageSize, posts = false) => {
    let startIndex = (pageNumber - 1) * pageSize;
    if (startIndex >= data.length) {
      return [];
    }
    if (!posts) {
      setPageNumber(pageNumber);
    } else {
      setPostPageNumber(pageNumber);
    }
    return data.slice(startIndex, startIndex + pageSize);
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={style.header}>
          <Title title={'Lets Explore'} />
          <Pressable style={style.messageIcon}>
            <FontAwesomeIcon icon={faEnvelope} color="#CACDDE" size={20} />
            <View style={style.messageNumberContainer}>
              <Text style={style.messageNumber}>2</Text>
            </View>
          </Pressable>
        </View>
        <View style={style.userStoryContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoading(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading) {
                setIsLoading(true);
                setRenderedData(prev => [
                  ...prev,
                  ...pagination(data, pageNumber + 1, pageSize),
                ]);
                setIsLoading(false);
              }
            }}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            data={renderedData}
            renderItem={({item}) => <UserStory firstName={item.firstName} />}
            keyExtractor={item => item.id.toString()}
          />
        </View>
        <View style={style.userPostContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoadingPosts(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoadingPosts) {
                setIsLoadingPosts(true);
                setRenderedDataPosts(prev => [
                  ...prev,
                  ...pagination(posts, postPageNumber + 1, pageSizePosts, true),
                ]);
                setIsLoadingPosts(false);
              }
            }}
            showsVerticalScrollIndicator={false}
            data={renderedDataPosts}
            renderItem={({item}) => (
              <UserPosts
                firstName={item.firstName}
                lastName={item.lastName}
                comments={item.comments}
                likes={item.likes}
                bookmarks={item.bookmarks}
                location={item.location}
                profileImage={item.profileImage}
                postImage={item.postImage}
              />
            )}
            keyExtractor={item => item.id.toString()}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default App;
*/














/*
import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Pressable,
  FlatList,
} from 'react-native';
import Title from './components/Title/Title';
import UserStory from './components/UserStory/UserStory';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome';
import {faEnvelope} from '@fortawesome/free-regular-svg-icons';
import style from './assets/styles/main';
import UserPosts from './components/UserPosts/UserPost';

const App = () => {
  const data = [
    {
      firstName: 'sepanta',
      id: 1,
      imageSource: require('./assets/images/1.jpg'),
    },
    {firstName: 'mark', id: 2, imageSource: require('./assets/images/2.jpg')},
    {firstName: 'white', id: 3, imageSource: require('./assets/images/3.jpg')},
    {firstName: 'sara', id: 4, imageSource: require('./assets/images/4.jpg')},
    {firstName: 'reza', id: 5, imageSource: require('./assets/images/5.jpg')},
    {firstName: 'mahdi', id: 6, imageSource: require('./assets/images/6.jpg')},
    {firstName: 'bita', id: 7, imageSource: require('./assets/images/7.jpg')},
    {firstName: 'mani', id: 8, imageSource: require('./assets/images/4.jpg')},
    {
      firstName: 'shabnam',
      id: 9,
      imageSource: require('./assets/images/5.jpg'),
    },
  ];

  const posts = [
    {
      firstName: 'sepanta',
      lastName: 'alizadeh',
      location: 'iran, tehran',
      likes: 2340,
      comments: 356,
      bookmarks: 55,
      id: 1,
      profileImage: require('./assets/images/1.jpg'),
      postImage: require('./assets/images/1.jpg'),
    },
    {
      firstName: 'selena',
      lastName: 'gomez',
      location: 'usa, newyork',
      likes: 6340,
      comments: 956,
      bookmarks: 455,
      id: 2,
      profileImage: require('./assets/images/2.jpg'),
      postImage: require('./assets/images/2.jpg'),
    },
    {
      firstName: 'ela',
      lastName: 'ka..',
      location: 'iran, tehran',
      likes: 40,
      comments: 56,
      bookmarks: 5,
      id: 3,
      profileImage: require('./assets/images/3.jpg'),
      postImage: require('./assets/images/3.jpg'),
    },
    {
      firstName: 'reza',
      lastName: 'asadi',
      location: 'iran, tehran',
      likes: 20,
      comments: 6,
      bookmarks: 45,
      id: 4,
      profileImage: require('./assets/images/4.jpg'),
      postImage: require('./assets/images/4.jpg'),
    },
    {
      firstName: 'mahshid',
      lastName: 'nazarai',
      location: 'iran, tehran',
      likes: 980,
      comments: 876,
      bookmarks: 15,
      id: 5,
      profileImage: require('./assets/images/5.jpg'),
      postImage: require('./assets/images/5.jpg'),
    },
  ];

  const pageSize = 4;
  const pageSizePosts = 2;
  const [pageNumber, setPageNumber] = useState(1);
  const [postPageNumber, setPostPageNumber] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  const [renderedData, setRenderedData] = useState(data.slice(0, pageSize));
  const [renderedDataPosts, setRenderedDataPosts] = useState(
    posts.slice(0, pageSizePosts),
  );

  const pagination = (data, pageNumber, pageSize, posts = false) => {
    let startIndex = (pageNumber - 1) * pageSize;
    if (startIndex >= data.length) {
      return [];
    }
    if (!posts) {
      setPageNumber(pageNumber);
    } else {
      setPostPageNumber(pageNumber);
    }
    return data.slice(startIndex, startIndex + pageSize);
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={style.header}>
          <Title title={'Lets Explore'} />
          <Pressable style={style.messageIcon}>
            <FontAwesomeIcon icon={faEnvelope} color="#CACDDE" size={20} />
            <View style={style.messageNumberContainer}>
              <Text style={style.messageNumber}>2</Text>
            </View>
          </Pressable>
        </View>
        <View style={style.userStoryContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoading(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading) {
                setIsLoading(true);
                setRenderedData(prev => [
                  ...prev,
                  ...pagination(data, pageNumber + 1, pageSize),
                ]);
                setIsLoading(false);
              }
            }}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            data={renderedData}
            renderItem={({item}) => (
              <UserStory
                firstName={item.firstName}
                imageSource={item.imageSource}
              />
            )}
            keyExtractor={item => item.id.toString()}
          />
        </View>
        <View style={style.userPostContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoadingPosts(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoadingPosts) {
                setIsLoadingPosts(true);
                setRenderedDataPosts(prev => [
                  ...prev,
                  ...pagination(posts, postPageNumber + 1, pageSizePosts, true),
                ]);
                setIsLoadingPosts(false);
              }
            }}
            showsVerticalScrollIndicator={false}
            data={renderedDataPosts}
            renderItem={({item}) => (
              <UserPosts
                firstName={item.firstName}
                lastName={item.lastName}
                comments={item.comments}
                likes={item.likes}
                bookmarks={item.bookmarks}
                location={item.location}
                profileImage={item.profileImage}
                postImage={item.postImage}
              />
            )}
            keyExtractor={item => item.id.toString()}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default App;

*/









import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Pressable,
  FlatList,
} from 'react-native';
import Title from './components/Title/Title';
import UserStory from './components/UserStory/UserStory';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faEnvelope } from '@fortawesome/free-regular-svg-icons';
import style from './assets/styles/main';
import UserPosts from './components/UserPosts/UserPost';

const App = () => {
  const data = [
    {
      firstName: 'sepanta',
      id: 1,
      imageSource: require('./assets/images/1.jpg'),
    },
    {firstName: 'mark', id: 2, imageSource: require('./assets/images/2.jpg')},
    {firstName: 'white', id: 3, imageSource: require('./assets/images/3.jpg')},
    {firstName: 'sara', id: 4, imageSource: require('./assets/images/4.jpg')},
    {firstName: 'reza', id: 5, imageSource: require('./assets/images/5.jpg')},
    {firstName: 'mahdi', id: 6, imageSource: require('./assets/images/6.jpg')},
    {firstName: 'bita', id: 7, imageSource: require('./assets/images/7.jpg')},
    {firstName: 'mani', id: 8, imageSource: require('./assets/images/4.jpg')},
    {
      firstName: 'shabnam',
      id: 9,
      imageSource: require('./assets/images/5.jpg'),
    },
  ];

  const posts = [
    {
      firstName: 'sepanta',
      lastName: 'alizadeh',
      location: 'iran, tehran',
      likes: 2340,
      comments: 356,
      bookmarks: 55,
      id: 1,
      profileImage: require('./assets/images/1.jpg'),
      postImage: require('./assets/images/1.jpg'),
    },
    {
      firstName: 'selena',
      lastName: 'gomez',
      location: 'usa, newyork',
      likes: 6340,
      comments: 956,
      bookmarks: 455,
      id: 2,
      profileImage: require('./assets/images/2.jpg'),
      postImage: require('./assets/images/2.jpg'),
    },
    {
      firstName: 'ela',
      lastName: 'ka..',
      location: 'iran, tehran',
      likes: 40,
      comments: 56,
      bookmarks: 5,
      id: 3,
      profileImage: require('./assets/images/3.jpg'),
      postImage: require('./assets/images/3.jpg'),
    },
    {
      firstName: 'reza',
      lastName: 'asadi',
      location: 'iran, tehran',
      likes: 20,
      comments: 6,
      bookmarks: 45,
      id: 4,
      profileImage: require('./assets/images/4.jpg'),
      postImage: require('./assets/images/4.jpg'),
    },
    {
      firstName: 'mahshid',
      lastName: 'nazarai',
      location: 'iran, tehran',
      likes: 980,
      comments: 876,
      bookmarks: 15,
      id: 5,
      profileImage: require('./assets/images/5.jpg'),
      postImage: require('./assets/images/5.jpg'),
    },
  ];

  const pageSize = 4;
  const pageSizePosts = 2;
  const [pageNumber, setPageNumber] = useState(1);
  const [postPageNumber, setPostPageNumber] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  const [renderedData, setRenderedData] = useState(data.slice(0, pageSize));
  const [renderedDataPosts, setRenderedDataPosts] = useState(
    posts.slice(0, pageSizePosts),
  );

  const pagination = (data, pageNumber, pageSize, posts = false) => {
    let startIndex = (pageNumber - 1) * pageSize;
    if (startIndex >= data.length) {
      return [];
    }
    if (!posts) {
      setPageNumber(pageNumber);
    } else {
      setPostPageNumber(pageNumber);
    }
    return data.slice(startIndex, startIndex + pageSize);
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={style.header}>
          <Title title={'Lets Explore'} />
          <Pressable style={style.messageIcon}>
            <FontAwesomeIcon icon={faEnvelope} color="#CACDDE" size={20} />
            <View style={style.messageNumberContainer}>
              <Text style={style.messageNumber}>2</Text>
            </View>
          </Pressable>
        </View>
        <View style={style.userStoryContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoading(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading) {
                setIsLoading(true);
                setRenderedData((prev) => [
                  ...prev,
                  ...pagination(data, pageNumber + 1, pageSize),
                ]);
                setIsLoading(false);
              }
            }}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            data={renderedData}
            renderItem={({ item }) => (
              <UserStory firstName={item.firstName} imageSource={item.imageSource} />
            )}
            keyExtractor={(item) => item.id.toString()}
          />
        </View>
        <View style={style.userPostContainer}>
          <FlatList
            onMomentumScrollBegin={() => setIsLoadingPosts(false)}
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoadingPosts) {
                setIsLoadingPosts(true);
                setRenderedDataPosts((prev) => [
                  ...prev,
                  ...pagination(posts, postPageNumber + 1, pageSizePosts, true),
                ]);
                setIsLoadingPosts(false);
              }
            }}
            showsVerticalScrollIndicator={false}
            data={renderedDataPosts}
            renderItem={({ item }) => (
              <UserPosts
                firstName={item.firstName}
                lastName={item.lastName}
                comments={item.comments}
                likes={item.likes}
                bookmarks={item.bookmarks}
                location={item.location}
                profileImage={item.profileImage}
                postImage={item.postImage}
              />
            )}
            keyExtractor={(item) => item.id.toString()}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default App;
