/*import React from 'react';
import {View, Image, Text} from 'react-native';
import PropTypes from 'prop-types';

import style from './style';

const UserStory = props => {
  return (
    <View style={style.storyContainer}>
      <View style={style.userImageContainer}>
        <Image style={style.storyImage} source={require('../../assets/images/4.jpg')} />
      </View>
      <Text style={style.name}>{props.firstName}</Text>
    </View>
  );
};

UserStory.PropTypes = {
  firstName: PropTypes.string.isRequired,
};

export default UserStory;
*/

import React from 'react';
import { View, Image, Text } from 'react-native';
import PropTypes from 'prop-types';

import style from './style';

const UserStory = (props) => {
  return (
    <View style={style.storyContainer}>
      <View style={style.userImageContainer}>
        <Image style={style.storyImage} source={props.imageSource} />
      </View>
      <Text style={style.name}>{props.firstName}</Text>
    </View>
  );
};

UserStory.propTypes = {
  firstName: PropTypes.string.isRequired,
  imageSource: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]).isRequired,
};

export default UserStory;

